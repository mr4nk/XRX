<?php
session_start();

// Check if session variable is set
if (!isset($_SESSION['username'])) {
    // Redirect to login page
    header("Location: login.php");
    exit();
}
// Logout functionality
if (isset($_GET['logout'])) {
    // Destroy the session
    session_destroy();
}
// Include your database connection file
require_once 'db_connection.php';

// Fetch user data from the database based on the user provided in the URL or the current user
if (isset($_GET['user'])) {
    // Sanitize the user input to prevent SQL injection
    $requested_user = mysqli_real_escape_string($conn, $_GET['user']);
    $sql = "SELECT * FROM users WHERE username = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $requested_user);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
    }
} else {
    // If user is not provided in the URL, fetch the profile of the current user
    $username = $_SESSION['username'];
    $sql = "SELECT * FROM users WHERE username = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
    }
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - EvilCorp IT Consultancy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('pxfuel(1).jpg'); /* Replace 'background-image.jpg' with the path to your background image */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff; /* Set font color to white */
            font-family: 'Courier New', Courier, monospace; /* Set font family to resemble terminal font */
            margin: 0;
            padding-bottom: 70px; /* Added padding to accommodate footer */
            text-align: center;
            min-height: 100vh; /* Ensure content stretches to at least the height of the viewport */
            position: relative; /* Add this for the footer positioning */
        }
        header {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px 0;
        }
        header h1 {
            font-size: 2.5em;
            margin: 0;
            color: #00ff00;
        }
        header nav ul {
            list-style: none;
            padding: 0;
        }
        header nav ul li {
            display: inline-block;
            margin-right: 20px;
        }
        header nav ul li a {
            text-decoration: none;
            color: #00ff00;
            transition: color 0.3s;
        }
        header nav ul li a:hover {
            color: #fff;
        }
        .content {
            padding: 50px 0;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: #00ff00;
            padding: 20px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        @media screen and (-webkit-min-device-pixel-ratio:0) {
            footer {
                position: fixed; /* Change to fixed positioning */
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>EvilCorp IT Consultancy</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="invoice.php">Upload Invoice</a></li>
                    <a href="?logout=true" class="btn btn-danger logout">Logout</a>
                </ul>
            </nav>
        </div>
    </header>
    <section class="content">
        <div class="container">
            <h2>User Profile</h2>
            <?php if ($row) : ?>
                <p>Name: <?php echo $row['first_name'] . ' ' . $row['last_name']; ?></p>
                <p>Email: <?php echo $row['company_email']; ?></p>
                <p>Address: <?php echo $row['address']; ?></p>
                <p>Company Name: <?php echo $row['company_name']; ?></p>
                <p>Phone Number: <?php echo $row['phone_number']; ?></p>
                <!-- Display the Password -->
                <p>Password: <?php echo $row['password']; ?></p>
                <!-- Add more profile content here -->
            <?php else : ?>
                <p>User not found.</p>
            <?php endif; ?>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; 2024 EvilCorp IT Consultancy. All rights reserved.</p>
        </div>
    </footer>
    <!-- <script src="profile.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
