<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection file
    include_once "db_connection.php"; // Change this to your actual database connection file

    // Get username and password from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Prepare and execute a SQL statement to fetch the user from the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows == 1) {
        // Fetch user data
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user["password"])) {
            // Password is correct, set session variables and redirect to profile page
            $_SESSION["username"] = $username;
            header("Location: dashboard.php"); // Change this to the actual profile page URL
            exit();
        } else {
            // Password is incorrect, redirect back to login page with an error message
            header("Location: login.php?error=invalid_credentials"); // Change this to the actual login page URL
            exit();
        }
    } else {
        // User not found, redirect back to login page with an error message
        header("Location: login.php?error=user_not_found"); // Change this to the actual login page URL
        exit();
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If the form is not submitted, redirect back to login page
    header("Location: login.php");
    exit();
}
?>
