<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EvilCorp IT Consultancy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('pxfuel(1).jpg'); /* Replace 'background-image.jpg' with the path to your background image */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff; /* Set font color to white */
            font-family: 'Courier New', Courier, monospace; /* Set font family to resemble terminal font */
            margin: 0;
            padding: 0;
            text-align: center;
        }
        header {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px 0;
        }
        header h1 {
            font-size: 2.5em;
            margin: 0;
            color: #00ff00;
        }
        header nav ul {
            list-style: none;
            padding: 0;
        }
        header nav ul li {
            display: inline-block;
            margin-right: 20px;
        }
        header nav ul li a {
            text-decoration: none;
            color: #00ff00;
            transition: color 0.3s;
        }
        header nav ul li a:hover {
            color: #fff;
        }
        .content {
            padding: 50px 0;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: #00ff00;
            padding: 20px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        @media screen and (-webkit-min-device-pixel-ratio:0) {
            footer {
                position: relative;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>EvilCorp IT Consultancy</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <section class="content">
        <div class="container">
            <h2>Login</h2>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <form action="login_process.php" method="POST">
                        <div class="form-group">
                            <input type="text" class="form-control" name="username" placeholder="Username">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="Password">
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; 2024 EvilCorp IT Consultancy. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
