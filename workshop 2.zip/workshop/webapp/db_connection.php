<?php
// Database configuration
$host = "custom_app_db"; // MySQL server host (usually "localhost")
$username = "evil_admin"; // MySQL username
$password = "dh4shamo0lAm"; // MySQL password
$database = "evilcorp_db"; // MySQL database name

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
